using UnityEngine;

namespace HAU;

public class AboutTab : ITab
{
    public string name => "About";

    public void Draw()
    {
        UIHelpers.BeginSection(ModBranding.Name, ModBranding.ShortName + " " + ModBranding.Version + " • By " + ModBranding.Creator);
        UIHelpers.Hint("Player tools, movement, outfit selection and host controls in one organized menu.");
        GUILayout.Label("Among Us version: " + Application.version);
        GUILayout.Label("Open HAU: " + HAUPlugin.menuKeybind.Value);
        UIHelpers.EndSection();
        UIHelpers.BeginSection("Getting started", "Choose a category on the left. Section descriptions explain what each tool changes.");
        UIHelpers.Hint("Movement: walking, sprint and player stunts.");
        UIHelpers.Hint("Appearance: your outfit, colours and local display.");
        UIHelpers.Hint("Tasks and Abilities: personal task and role tools.");
        UIHelpers.Hint("Host Controls: shared settings for a lobby you host.");
        UIHelpers.Hint("Settings: keybinds, profiles, colours and automatic updates.");
        UIHelpers.EndSection();
        UIHelpers.BeginSection("Project", "HAU is maintained by Rifegul. Distributed license notices are included with the download.");
        if (GUILayout.Button("Open the HAU project")) Application.OpenURL("https://github.com/ProXgram/HackerAmongUs");
        UIHelpers.EndSection();
    }
}
