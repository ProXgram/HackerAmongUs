using UnityEngine;

namespace HAU;

public class RolesUI : MonoBehaviour
{
    public static int windowHeight = 100;
    public static int windowWidth = 450;
    public static Rect windowRect;

    private Vector2 _scrollPosition = Vector2.zero;

    private void Start()
    {
        // Instantiate 2D area of RolesUI
        windowRect = new(
            Screen.width / 2f - windowWidth / 2f,
            Screen.height / 2f - windowHeight / 2f,
            windowWidth,
            windowHeight
        );
    }

    private void OnGUI()
    {
        if (!CheatToggles.showRolesMenu || !(MenuUI.isGUIActive || HAUPlugin.menuKeepSubwindowsOpen.Value) || HAUPlugin.isPanicked) return;

        using var theme = UIHelpers.UseTheme();

        windowRect = GUI.Window((int)WindowId.RolesUI, windowRect, (GUI.WindowFunction)RolesWindow, "HAU / Assign Roles", GUIStylePreset.Window);
    }

    private void RolesWindow(int windowID)
    {
        if (GUI.Button(new Rect(windowRect.width - 29f, 3f, 24f, 20f), "X"))
            CheatToggles.showRolesMenu = false;
        GUILayout.BeginVertical();

        _scrollPosition = GUILayout.BeginScrollView(_scrollPosition, false, true);

        foreach (var player in PlayerControl.AllPlayerControls)
        {
            if (!player.Data || !player.Data.Role || string.IsNullOrEmpty(player.Data.PlayerName) || player != PlayerControl.LocalPlayer) continue;

            GUILayout.BeginHorizontal();

            GUILayout.Label($"<color=#{ColorUtility.ToHtmlStringRGB(player.Data.Color)}>{player.Data.PlayerName}</color>", GUILayout.Width(140f));
            GUILayout.BeginHorizontal();
            GUILayout.Label($"{CheatToggles.forcedRole}");
            GUILayout.FlexibleSpace();

            if (GUILayout.Button("Reset", GUILayout.Width(80f)))
            {
                CheatToggles.forcedRole = null;
            }
            if (GUILayout.Button("Assign", GUILayout.Width(80f)))
            {
                CheatToggles.forceRole = true;
            }

            GUILayout.EndHorizontal();
            GUILayout.EndHorizontal();
        }

        GUILayout.EndScrollView();
        GUILayout.EndVertical();
        UIHelpers.Hint("Your selected role applies on the next game start.");
        GUI.DragWindow();
    }
}
