public enum WindowId
{
    MenuUI = 0,
    ConsoleUI = 1,
    DoorsUI = 2,
    TasksUI = 3,
    RolesUI = 4,
    ProtectUI = 5,
    OverloadUI = 6,
    MultiRoleUI = 7,
    OutfitPickerUI = 8
}
